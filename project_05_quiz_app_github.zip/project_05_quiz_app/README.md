# Project 05 – Quiz App

A Flutter multiple-choice quiz application created to meet the InternCircle Project 05 learner guide.

## Topic
Flutter and Dart fundamentals.

## Features implemented

- A `Question` model with question text, options and correct answer index
- Exactly 10 multiple-choice questions
- Four options for every question
- Current question number and `LinearProgressIndicator`
- Current score display
- Correct answer feedback in green
- Incorrect selected answer feedback in red, with the correct answer identified
- Answer options are disabled after the first selection to prevent double scoring
- Next Question button appears after answering
- Results screen showing score out of 10 and percentage
- Try Again button resets question index, score and selection
- Question data is kept in a separate constant list

## Run in DartPad (as requested by the learner guide)

1. Open https://dartpad.dev/
2. Select **Flutter**.
3. Open `lib/main.dart` from this repository.
4. Copy the complete code into DartPad.
5. Click **Run**.

No external packages are required.

## Test checklist

1. Play the quiz and choose the correct answer for all ten questions. The result should be 10/10.
2. Restart, then choose an incorrect answer for all ten questions. The result should be 0/10.
3. Restart and answer with a mixture of correct and incorrect options.
4. Check that the correct option turns green and an incorrect selected option turns red.
5. Tap an answer more than once and confirm the score does not increase again.
6. Confirm Next Question is enabled only after an answer is selected.
7. Confirm the results screen appears after question ten.
8. Press Try Again and confirm the quiz starts at question one with score zero.

## Submission items from the guide

- DartPad link
- Screenshots of a question screen and the results screen
- Your list of ten questions

Upload this repository to GitHub and allow anyone with the link to view it. Include your DartPad link and screenshots when submitting through the InternCircle My Tasks page.

## Note

This beginner/intermediate project keeps the score and current selection in widget state. It does not use a database or persistent storage because those are not part of the supplied Project 05 requirements.
